﻿#include <iostream>

using namespace std;

const int N = 8; // Размер доски

// Функция для проверки, можно ли поставить ферзя на доску в позиции (row, col)
bool isSafe(int board[N][N], int row, int col) {
    int i, j;
    // Проверяем эту строку слева
    for (i = 0; i < col; ++i)
        if (board[row][i])
            return false;
    // Проверяем верхнюю диагональ слева
    for (i = row, j = col; i >= 0 && j >= 0; --i, --j)
        if (board[i][j])
            return false;
    // Проверяем нижнюю диагональ слева
    for (i = row, j = col; j >= 0 && i < N; ++i, --j)
        if (board[i][j])
            return false;
    return true;
}

// Функция для вывода шахматной доски с цветовой разметкой
void printBoard(int board[N][N]) {
    cout << "  ";
    for (int i = 0; i < N; ++i)
        cout << "\033[1;37m" << i << " ";
    cout << endl;
    for (int i = 0; i < N; ++i) {
        cout << "\033[1;37m" << i << " ";
        for (int j = 0; j < N; ++j) {
            if ((i + j) % 2 == 0)
                cout << "\033[48;5;235m"; // Зеленый фон для четных клеток
            else
                cout << "\033[48;5;234m"; // Белый фон для нечетных клеток

            if (board[i][j])
                cout << "\033[1;31mQ\033[0m "; // Красный цвет для ферзей
            else
                cout << "  ";
        }
        cout << "\033[0m" << endl;
    }
    cout << endl;
}

// Рекурсивная функция для решения задачи о 8 ферзях
bool solveNQueensUtil(int board[N][N], int col) {
    // Базовый случай: если все ферзи размещены, возвращаем true
    if (col >= N)
        return true;

    // Перебираем строки в текущем столбце
    for (int i = 0; i < N; ++i) {
        // Проверяем, можно ли поставить ферзя в позицию (i, col)
        if (isSafe(board, i, col)) {
            // Расставляем ферзя
            board[i][col] = 1;

            // Выводим положение на текущем шаге
            cout << "Шаг " << col + 1 << ": Размещаем ферзя в позиции (" << i << ", " << col << ")" << endl;
            printBoard(board);

            // Рекурсивно вызываем solveNQueensUtil для следующего столбца
            if (solveNQueensUtil(board, col + 1))
                return true;

            // Если не можем разместить ферзя в данной позиции, возвращаемся и пробуем другую
            board[i][col] = 0;
            cout << "Шаг " << col + 1 << ": Удаляем ферзя из позиции (" << i << ", " << col << ")" << endl;
            printBoard(board);
        }
    }
    // Если не удалось разместить ферзя в текущем столбце, возвращаем false
    return false;
}

// Функция для решения задачи о 8 ферзях
void solveNQueens() {
    int board[N][N] = { 0 }; // Создаем пустую доску

    // Вызываем вспомогательную рекурсивную функцию для размещения ферзей
    if (!solveNQueensUtil(board, 0))
        cout << "Решение не существует" << endl;
}

int main() {
    setlocale(LC_ALL, "ru");
    solveNQueens();
    system("pause");
}
